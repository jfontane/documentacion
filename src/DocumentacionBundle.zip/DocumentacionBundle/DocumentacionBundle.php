<?php

namespace DocumentacionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DocumentacionBundle extends Bundle
{
}
